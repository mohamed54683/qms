<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',
        'brand',
        'type', // keeping for backward compatibility
        'status',
        'address',
        'city',
        'location', // keeping for backward compatibility
        'phone',
        'email',
        'manager',
        'manager_id', // keeping for backward compatibility
        'restaurant_manager_id',
        'area_manager_id',
        'opening_hours',
        'seating_capacity',
        'staff_count',
        'notes',
        'is_active'
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
        ];
    }

    public function users()
    {
        return $this->belongsToMany(User::class);
    }

    public function manager()
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    public function restaurantManager()
    {
        return $this->belongsTo(User::class, 'restaurant_manager_id');
    }

    public function areaManager()
    {
        return $this->belongsTo(User::class, 'area_manager_id');
    }
}
