<?php
namespace App\Http\Controllers;

use App\Models\TemperatureTrackingForm;
use App\Models\Restaurant;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;
use App\Exports\TemperatureTrackingExport;
use Maatwebsite\Excel\Facades\Excel;

class TemperatureTrackingController extends Controller
{
    public function index(Request $request)
    {
        $query = TemperatureTrackingForm::with('store','creator');
        if ($request->store_id) $query->where('store_id', $request->store_id);
        if ($request->date_from) $query->where('date', '>=', $request->date_from);
        if ($request->date_to) $query->where('date', '<=', $request->date_to);
        if ($request->status) $query->where('status', $request->status);
        
        // Handle PDF export
        if ($request->export === 'pdf') {
            $forms = $query->orderBy('date','desc')->get();
            $stores = Restaurant::all(['id','name']);
            
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('temperature-tracking.pdf', compact('forms', 'stores'));
            return $pdf->download('temperature-tracking-report-' . date('Y-m-d') . '.pdf');
        }
        
        $forms = $query->orderBy('date','desc')->paginate(20);
        $stores = Restaurant::all(['id','name']);
        return Inertia::render('TemperatureTracking/Index', compact('forms','stores'));
    }
    public function create()
    {
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        $stores = Restaurant::all(['id','name']);
        return Inertia::render('TemperatureTracking/Create', [
            'stores' => $stores,
            'isAdmin' => $isAdmin,
        ]);
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'store_id' => 'required|exists:restaurants,id',
            'mic_morning' => 'required|string',
            'mic_evening' => 'required|string',
            'shift' => 'required|string|in:morning,evening',
            'date' => 'required|date',
            'cooked_products' => 'nullable|array',
            'holding_products' => 'nullable|array',
            'side_cooked' => 'nullable|array',
            'side_holding' => 'nullable|array',
            'vegetables' => 'nullable|array',
            'vegetable_receiving' => 'nullable|array',
            'equipment' => 'nullable|array',
            'sanitizer' => 'nullable|array',
            'receiving_products' => 'nullable|array',
            'product_receiving_side' => 'nullable|array',
            'corrective_action' => 'nullable|string',
            'corrective_action_upper' => 'nullable|string',
            'corrective_action_lower' => 'nullable|string',
            'shift_turnover' => 'nullable|array',
            'status' => 'required|in:Draft,Submitted,Reviewed',
        ]);
        // Backend compliance enforcement
        $outOfRange = false;
        $sanitizerOut = false;
        $tempBlocks = ['cooked_products','holding_products','side_cooked','side_holding','vegetables'];
        foreach ($tempBlocks as $block) {
            if (!empty($data[$block]) && is_array($data[$block])) {
                foreach ($data[$block] as $prod) {
                    if (!is_array($prod)) continue;
                    foreach ($prod as $val) {
                        if ($val === '' || $val === null) continue;
                        $num = floatval($val);
                        if ($block === 'vegetables' && ($num < 36 || $num > 40)) $outOfRange = true;
                        if (in_array($block, ['cooked_products','side_cooked']) && ($num < 160 || $num > 165)) $outOfRange = true;
                        if (in_array($block, ['holding_products','side_holding']) && $num < 140) $outOfRange = true;
                    }
                }
            }
        }
        if (!empty($data['sanitizer']) && is_array($data['sanitizer'])) {
            foreach ($data['sanitizer'] as $val) {
                if ($val === '' || $val === null) continue;
                $num = floatval($val);
                if ($num < 150 || $num > 300) $sanitizerOut = true;
            }
        }
        $corrective = trim(($data['corrective_action_upper'] ?? '') . ($data['corrective_action_lower'] ?? ''));
        if (($outOfRange || $sanitizerOut) && strlen($corrective) < 3 && $data['status'] === 'Submitted') {
            return back()->withErrors(['corrective_action_upper' => 'Corrective action is required for out-of-range values.'])->withInput();
        }
        // Notification logic stub: Area Manager if product receiving Y/N is N or shift turnover is ✖
        $notifyAreaManager = false;
        if (!empty($data['receiving_products']) && is_array($data['receiving_products'])) {
            foreach ($data['receiving_products'] as $prod) {
                if (isset($prod['yn']) && strtoupper($prod['yn']) === 'N') $notifyAreaManager = true;
            }
        }
        if (!empty($data['product_receiving_side']) && is_array($data['product_receiving_side'])) {
            foreach ($data['product_receiving_side'] as $prod) {
                if (isset($prod['yn']) && strtoupper($prod['yn']) === 'N') $notifyAreaManager = true;
            }
        }
        if (!empty($data['shift_turnover']) && is_array($data['shift_turnover'])) {
            foreach (['morning','evening'] as $shift) {
                if (!empty($data['shift_turnover'][$shift]) && is_array($data['shift_turnover'][$shift])) {
                    foreach ($data['shift_turnover'][$shift] as $val) {
                        if (trim($val) === 'x' || trim($val) === '✖') $notifyAreaManager = true;
                    }
                }
            }
        }
        // TODO: Implement actual notification to Area Manager if $notifyAreaManager is true
        $data['created_by'] = Auth::id();
        TemperatureTrackingForm::create($data);
        return redirect()->route('temperature-tracking.index')->with('success','Form submitted!');
    }
    public function show(TemperatureTrackingForm $temperatureTrackingForm)
    {
        $temperatureTrackingForm->load('store','creator');
        return Inertia::render('TemperatureTracking/Show', [
            'form' => $temperatureTrackingForm
        ]);
    }
    public function edit(TemperatureTrackingForm $temperatureTrackingForm)
    {
        $stores = Restaurant::all(['id','name']);
        return Inertia::render('TemperatureTracking/Create', [
            'form' => $temperatureTrackingForm,
            'stores' => $stores
        ]);
    }
    public function update(Request $request, TemperatureTrackingForm $temperatureTrackingForm)
    {
        $data = $request->validate([
            'store_id' => 'required|exists:restaurants,id',
            'mic_morning' => 'required|string',
            'mic_evening' => 'required|string',
            'shift' => 'required|string|in:morning,evening',
            'date' => 'required|date',
            'cooked_products' => 'nullable|array',
            'holding_products' => 'nullable|array',
            'side_cooked' => 'nullable|array',
            'side_holding' => 'nullable|array',
            'vegetables' => 'nullable|array',
            'vegetable_receiving' => 'nullable|array',
            'equipment' => 'nullable|array',
            'sanitizer' => 'nullable|array',
            'receiving_products' => 'nullable|array',
            'product_receiving_side' => 'nullable|array',
            'corrective_action' => 'nullable|string',
            'corrective_action_upper' => 'nullable|string',
            'corrective_action_lower' => 'nullable|string',
            'shift_turnover' => 'nullable|array',
            'status' => 'required|in:Draft,Submitted,Reviewed',
        ]);
        // Backend compliance enforcement for update
        $outOfRange = false;
        $sanitizerOut = false;
        $tempBlocks = ['cooked_products','holding_products','side_cooked','side_holding','vegetables'];
        foreach ($tempBlocks as $block) {
            if (!empty($data[$block]) && is_array($data[$block])) {
                foreach ($data[$block] as $prod) {
                    if (!is_array($prod)) continue;
                    foreach ($prod as $val) {
                        if ($val === '' || $val === null) continue;
                        $num = floatval($val);
                        if ($block === 'vegetables' && ($num < 36 || $num > 40)) $outOfRange = true;
                        if (in_array($block, ['cooked_products','side_cooked']) && ($num < 160 || $num > 165)) $outOfRange = true;
                        if (in_array($block, ['holding_products','side_holding']) && $num < 140) $outOfRange = true;
                    }
                }
            }
        }
        if (!empty($data['sanitizer']) && is_array($data['sanitizer'])) {
            foreach ($data['sanitizer'] as $val) {
                if ($val === '' || $val === null) continue;
                $num = floatval($val);
                if ($num < 150 || $num > 300) $sanitizerOut = true;
            }
        }
        $corrective = trim(($data['corrective_action_upper'] ?? '') . ($data['corrective_action_lower'] ?? ''));
        if (($outOfRange || $sanitizerOut) && strlen($corrective) < 3 && $data['status'] === 'Submitted') {
            return back()->withErrors(['corrective_action_upper' => 'Corrective action is required for out-of-range values.'])->withInput();
        }
        $temperatureTrackingForm->update($data);
        return redirect()->route('temperature-tracking.index')->with('success','Form updated!');
    }
    public function destroy(TemperatureTrackingForm $temperatureTrackingForm)
    {
        $temperatureTrackingForm->delete();
        return back()->with('success','Form deleted!');
    }

    /**
     * Export Temperature Tracking to Excel
     */
    public function export(Request $request)
    {
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        // Get filters from request
        $filters = [
            'store_id' => $request->input('store_id'),
            'date_from' => $request->input('date_from'),
            'date_to' => $request->input('date_to'),
            'status' => $request->input('status'),
            'shift' => $request->input('shift'),
        ];
        
        $filename = 'temperature-tracking-export-' . date('Y-m-d-His') . '.xlsx';
        
        return Excel::download(new TemperatureTrackingExport($filters, $isAdmin), $filename);
    }
}