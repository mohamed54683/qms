<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StoreVisit extends Model
{
    protected $fillable = [
        'user_id', 'restaurant_name', 'mic', 'visit_date', 'score', 'purpose_of_visit',
        
        // Section A: Customer / QSC
        'oca_board_followed', 'oca_board_comments', 'staff_know_duty', 'staff_duty_comments',
        'coaching_directing', 'coaching_comments',
        
        // Section B: Cashier
        'smile_greetings', 'smile_comments', 'suggestive_selling', 'suggestive_comments',
        'offer_promotion', 'promotion_comments', 'thank_direction', 'thank_comments',
        
        // Section C: Service Standards
        'team_work_hustle', 'teamwork_comments', 'order_accuracy', 'accuracy_comments',
        'service_time', 'service_comments', 'dine_in', 'dine_comments', 'take_out', 'takeout_comments',
        'family', 'family_comments', 'delivery', 'delivery_comments', 'drive_thru', 'drive_comments',
        
        // Section D: Financials
        'weekly_schedule', 'schedule_comments', 'mod_financial_goal', 'financial_comments',
        'sales_objectives', 'sales_comments', 'cash_policies', 'cash_comments',
        'daily_waste', 'waste_comments',
        
        // Section E: Quality / Pathing
        'ttf_followed', 'ttf_comments', 'sandwich_assembly', 'assembly_comments',
        'qsc_completed', 'qsc_comments', 'oil_standards', 'oil_comments',
        'day_labels', 'labels_comments', 'equipment_working', 'equipment_comments',
        'fryer_condition', 'fryer_comments', 'vegetable_prep', 'vegetable_comments',
        'employee_appearance', 'appearance_comments',
        
        // Section F: Cleanliness
        'equipment_wrapped', 'wrapped_comments', 'sink_setup', 'sink_comments',
        'sanitizer_standard', 'sanitizer_comments', 'dining_area_clean', 'dining_comments',
        'restroom_clean', 'restroom_comments',
        
        // Section 8: Follow-up
        'last_visit_date', 'last_visit_summary', 'last_visit_update', 'other_follow_up',
        
        // Section 9: Observation Summary
        'what_did_you_see', 'why_had_issue', 'how_to_improve', 'who_when_responsible',
        
        // Section 10: Action Plan (Auto-Generated)
        'action_plan_items',
        
        // Section 11: Report Management
        'performance_score_percentage', 'report_timestamp', 'digital_signature_mic', 
        'digital_signature_reviewer', 'report_type', 'export_history',
        'created_by_name', 'reviewer_name', 'reviewed_at', 'approved_at',
        
        // Additional fields
        'general_comments', 'photos', 'status', 'attachments'
    ];

    protected $casts = [
        'visit_date' => 'date',
        'last_visit_date' => 'date',
        'purpose_of_visit' => 'array',
        'photos' => 'array',
        'action_plan_items' => 'array',
        'export_history' => 'array',
        'attachments' => 'array',
        'report_timestamp' => 'datetime',
        'reviewed_at' => 'datetime',
        'approved_at' => 'datetime',
        'performance_score_percentage' => 'decimal:2',
        
        // Cast boolean fields
        'oca_board_followed' => 'boolean',
        'staff_know_duty' => 'boolean',
        'coaching_directing' => 'boolean',
        'smile_greetings' => 'boolean',
        'suggestive_selling' => 'boolean',
        'offer_promotion' => 'boolean',
        'thank_direction' => 'boolean',
        'team_work_hustle' => 'boolean',
        'order_accuracy' => 'boolean',
        'service_time' => 'boolean',
        'dine_in' => 'boolean',
        'take_out' => 'boolean',
        'family' => 'boolean',
        'delivery' => 'boolean',
        'drive_thru' => 'boolean',
        'weekly_schedule' => 'boolean',
        'mod_financial_goal' => 'boolean',
        'sales_objectives' => 'boolean',
        'cash_policies' => 'boolean',
        'daily_waste' => 'boolean',
        'ttf_followed' => 'boolean',
        'sandwich_assembly' => 'boolean',
        'qsc_completed' => 'boolean',
        'oil_standards' => 'boolean',
        'day_labels' => 'boolean',
        'equipment_working' => 'boolean',
        'fryer_condition' => 'boolean',
        'vegetable_prep' => 'boolean',
        'employee_appearance' => 'boolean',
        'equipment_wrapped' => 'boolean',
        'sink_setup' => 'boolean',
        'sanitizer_standard' => 'boolean',
        'dining_area_clean' => 'boolean',
        'restroom_clean' => 'boolean',
    ];

    /**
     * Get the user that owns the store visit.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the action plans associated with this store visit.
     */
    public function actionPlans(): HasMany
    {
        return $this->hasMany(ActionPlan::class);
    }

    /**
     * Get the restaurant associated with this store visit.
     */
    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class, 'restaurant_name', 'name');
    }

    /**
     * Calculate the score based on Y/N answers
     */
    public function calculateScore(): int
    {
        $totalQuestions = 34; // Total number of questions from all sections
        $yesCount = 0;

        // Count all the 'Yes' answers (true values)
        $booleanFields = [
            'oca_board_followed', 'staff_know_duty', 'coaching_directing',
            'smile_greetings', 'suggestive_selling', 'offer_promotion', 'thank_direction',
            'team_work_hustle', 'order_accuracy', 'service_time', 'dine_in', 'take_out', 'family', 'delivery', 'drive_thru',
            'weekly_schedule', 'mod_financial_goal', 'sales_objectives', 'cash_policies', 'daily_waste',
            'ttf_followed', 'sandwich_assembly', 'qsc_completed', 'oil_standards', 'day_labels', 'equipment_working', 'fryer_condition', 'vegetable_prep', 'employee_appearance',
            'equipment_wrapped', 'sink_setup', 'sanitizer_standard', 'dining_area_clean', 'restroom_clean'
        ];

        foreach ($booleanFields as $field) {
            if ($this->$field === true) {
                $yesCount++;
            }
        }

        return $totalQuestions > 0 ? round(($yesCount / $totalQuestions) * 100) : 0;
    }

    /**
     * Get items that need action (answered 'No')
     */
    public function getActionItems(): array
    {
        $actionItems = [];
        
        $questionMap = [
            'oca_board_followed' => 'OCA Board is Completely Followed/Communicated',
            'staff_know_duty' => 'Staff Know their Side Duty',
            'coaching_directing' => 'Coaching and Directing',
            'smile_greetings' => 'Smile and Friendly Greetings',
            'suggestive_selling' => 'Suggestive Selling',
            'offer_promotion' => 'Offer new Promotion',
            'thank_direction' => 'Saying Thank You and Provides Direction',
            'team_work_hustle' => 'Team Work and Hustle',
            'order_accuracy' => 'Order Accuracy',
            'service_time' => 'Service Time',
            'dine_in' => 'Dine In',
            'take_out' => 'Take Out',
            'family' => 'Family',
            'delivery' => 'Delivery',
            'drive_thru' => 'Drive Thru',
            'weekly_schedule' => 'Weekly Schedule and Overtime',
            'mod_financial_goal' => 'MOD aware of Financial Goal',
            'sales_objectives' => 'Sales (Cashier Objectives)',
            'cash_policies' => 'Cash Policies followed Spot Check',
            'daily_waste' => 'Daily Waste Followed Properly (Daily)',
            'ttf_followed' => 'TTF followed properly',
            'sandwich_assembly' => 'Sandwich Assembly being followed',
            'qsc_completed' => 'QSC was completed and followed properly',
            'oil_standards' => 'Oil/Shortening Meets Standards',
            'day_labels' => 'Day Labels updated',
            'equipment_working' => 'Equipments are all working properly',
            'fryer_condition' => 'Fryer Basket in Good Condition (not broken or rusty)',
            'vegetable_prep' => 'Vegetable Preparation meets standards and Salad Prep',
            'employee_appearance' => 'Employee Appearance well groomed',
            'equipment_wrapped' => 'Equipment are wrapped and hang',
            'sink_setup' => 'Compartment sink are set-up properly',
            'sanitizer_standard' => 'Sanitizer meets standard',
            'dining_area_clean' => 'Dining Area/Family area no busting',
            'restroom_clean' => 'CR or handwash area has tissue and clean'
        ];

        foreach ($questionMap as $field => $question) {
            if ($this->$field === false) {
                $actionItems[] = [
                    'question' => $question,
                    'field' => $field,
                    'comment' => $this->{$field . '_comments'} ?? ''
                ];
            }
        }

        return $actionItems;
    }

    // New relationships for workflow
    public function answers(): HasMany
    {
        return $this->hasMany(StoreVisitAnswer::class, 'visit_id');
    }

    public function areaManager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'area_manager_id');
    }

    public function storeManager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'store_manager_id');
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    /**
     * Scope to filter visits by user's assigned restaurants
     */
    public function scopeForUserRestaurants($query, $user = null)
    {
        if (!$user) {
            $user = auth()->user();
        }

        if (!$user) {
            return $query->whereRaw('1 = 0'); // Return empty result
        }

        // If user has admin role, return all visits
        if ($user->hasRole('admin')) {
            return $query;
        }

        // Get user's assigned restaurant names
        $restaurantNames = $user->restaurants->pluck('name')->toArray();

        if (empty($restaurantNames)) {
            return $query->whereRaw('1 = 0'); // Return empty result
        }

        return $query->whereIn('restaurant_name', $restaurantNames);
    }
}
