<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Deprecated: logic moved into 2025_10_09_010000_align_temperature_tracking_forms_base_structure.php
return new class extends Migration {
    public function up(): void { /* no-op */ }
    public function down(): void { /* no-op */ }
};