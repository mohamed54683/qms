<?php

namespace App\Http\Controllers;

use App\Models\StoreVisit;
use App\Models\Restaurant;
use App\Models\ActionPlan;
use App\Exports\StoreVisitsExport;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Barryvdh\DomPDF\Facade\Pdf;

class StoreVisitController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        // Build query for store visits with optimized relationships
        $query = StoreVisit::with(['user.roles', 'actionPlans']);
        
        // Apply restaurant filtering based on user's assigned restaurants
        if (!$isAdmin) {
            // Filter by user's assigned restaurants
            $query->forUserRestaurants($user);
        }
        
        // Apply filters
        if ($request->filled('restaurant')) {
            $query->where('restaurant_name', 'LIKE', '%' . $request->restaurant . '%');
        }
        
        if ($request->filled('mic')) {
            $query->where('mic', $request->mic);
        }
        
        if ($request->filled('date_from')) {
            $query->where('visit_date', '>=', $request->date_from);
        }
        
        if ($request->filled('date_to')) {
            $query->where('visit_date', '<=', $request->date_to);
        }
        
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('restaurant_name', 'LIKE', '%' . $search . '%')
                  ->orWhere('general_comments', 'LIKE', '%' . $search . '%')
                  ->orWhere('oca_board_comments', 'LIKE', '%' . $search . '%')
                  ->orWhere('staff_duty_comments', 'LIKE', '%' . $search . '%')
                  ->orWhere('what_did_you_see', 'LIKE', '%' . $search . '%')
                  ->orWhere('why_had_issue', 'LIKE', '%' . $search . '%')
                  ->orWhere('how_to_improve', 'LIKE', '%' . $search . '%');
            });
        }
        
        if ($request->filled('purpose')) {
            $query->whereJsonContains('purpose_of_visit', $request->purpose);
        }
        
        if ($request->filled('score_min')) {
            $query->whereRaw('COALESCE(score, 0) >= ?', [$request->score_min]);
        }
        
        if ($request->filled('score_max')) {
            $query->whereRaw('COALESCE(score, 0) <= ?', [$request->score_max]);
        }
        
        // Get visits with optimized performance (limit records and avoid expensive calculations)
        $visits = $query->latest('visit_date')->limit(50)->get()->map(function ($visit) {
            $actionItems = $visit->getActionItems(); // Get "No" answers
            $existingActionPlans = $visit->actionPlans->count();
            
            return [
                'id' => $visit->id,
                'restaurant' => $visit->restaurant_name,
                'mic' => $visit->mic,
                'date' => $visit->visit_date->format('Y-m-d'),
                'score' => $visit->score ?? 0, // Use cached score for performance
                'purpose' => $visit->purpose_of_visit,
                'status' => $visit->status,
                'actionItems' => count($actionItems), // Count of "No" answers
                'existingActionPlans' => $existingActionPlans, // Count of existing action plans
                'hasIssues' => count($actionItems) > 0, // Has "No" answers
                'needsActionPlans' => count($actionItems) > 0 && $existingActionPlans === 0, // Has issues but no action plans yet
                'issuesSummary' => count($actionItems) > 0 ? count($actionItems) . ' issue' . (count($actionItems) > 1 ? 's' : '') . ' found' : 'No issues found',
                'created_by' => $visit->user->name,
                'created_by_role' => $visit->user->roles?->first()?->name ?? 'User',
                'created_at' => $visit->created_at->format('M j, Y g:i A')
            ];
        });
        
        // Get all restaurants from the 68-restaurant database for filter dropdown
        $restaurants = \App\Models\Restaurant::where('is_active', true)
                                            ->select('id', 'name', 'code', 'location')
                                            ->orderBy('code')
                                            ->get();
        
        return Inertia::render('StoreVisit/Index', [
            'visits' => $visits,
            'restaurants' => $restaurants,
            'filters' => $request->only(['restaurant', 'mic', 'date_from', 'date_to', 'status', 'search', 'purpose', 'score_min', 'score_max', 'has_action_items']),
            'isAdmin' => $isAdmin,
            'canExportAll' => $isAdmin,
            'canViewAllRestaurants' => $isAdmin,
            'csrf_token' => csrf_token()
        ]);
    }

    public function create()
    {
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        $restaurants = \App\Models\Restaurant::where('is_active', true)
                                            ->select('id', 'name', 'code', 'location')
                                            ->orderBy('code')
                                            ->get();
        
        return Inertia::render('StoreVisit/Create', [
            'restaurants' => $restaurants,
            'isAdmin' => $isAdmin,
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'restaurant_name' => 'required|string|max:255',
            'mic' => 'required|in:Morning,Evening',
            'visit_date' => 'required|date',
            'purpose_of_visit' => 'required|array|min:1',
            'purpose_of_visit.*' => 'in:Quality Audit,Operational Assessment,Training Audit,Measurement & Coaching',
            
            // All boolean fields are nullable but must be boolean if provided
            'oca_board_followed' => 'nullable|boolean',
            'staff_know_duty' => 'nullable|boolean',
            'coaching_directing' => 'nullable|boolean',
            'smile_greetings' => 'nullable|boolean',
            'suggestive_selling' => 'nullable|boolean',
            'offer_promotion' => 'nullable|boolean',
            'thank_direction' => 'nullable|boolean',
            'team_work_hustle' => 'nullable|boolean',
            'order_accuracy' => 'nullable|boolean',
            'service_time' => 'nullable|boolean',
            'dine_in' => 'nullable|boolean',
            'take_out' => 'nullable|boolean',
            'family' => 'nullable|boolean',
            'delivery' => 'nullable|boolean',
            'drive_thru' => 'nullable|boolean',
            'weekly_schedule' => 'nullable|boolean',
            'mod_financial_goal' => 'nullable|boolean',
            'sales_objectives' => 'nullable|boolean',
            'cash_policies' => 'nullable|boolean',
            'daily_waste' => 'nullable|boolean',
            'ttf_followed' => 'nullable|boolean',
            'sandwich_assembly' => 'nullable|boolean',
            'qsc_completed' => 'nullable|boolean',
            'oil_standards' => 'nullable|boolean',
            'day_labels' => 'nullable|boolean',
            'equipment_working' => 'nullable|boolean',
            'fryer_condition' => 'nullable|boolean',
            'vegetable_prep' => 'nullable|boolean',
            'employee_appearance' => 'nullable|boolean',
            'equipment_wrapped' => 'nullable|boolean',
            'sink_setup' => 'nullable|boolean',
            'sanitizer_standard' => 'nullable|boolean',
            'dining_area_clean' => 'nullable|boolean',
            'restroom_clean' => 'nullable|boolean',
            
            'general_comments' => 'nullable|string',
            'status' => 'nullable|in:Draft,Submitted,Reviewed,Approved'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // Create the store visit
        $data = $request->all();
        $data['user_id'] = auth()->id();
        $data['status'] = $data['status'] ?? 'Submitted';

        $storeVisit = StoreVisit::create($data);
        
        // Calculate and update score
        $storeVisit->score = $storeVisit->calculateScore();
        $storeVisit->save();

        // If status is Draft, redirect to index immediately
        if ($storeVisit->status === 'Draft') {
            return redirect()->route('store-visits.index')
                           ->with('success', 'Store visit report saved as draft successfully!');
        }

        // Check if there are action items that need confirmation
        $actionItems = $storeVisit->getActionItems();
        
        if (count($actionItems) > 0) {
            // Redirect to show page with confirmation prompt
            return redirect()->route('store-visits.show', $storeVisit->id)
                           ->with('success', 'Store visit report created successfully!')
                           ->with('confirm', true);
        } else {
            // No action items needed, go directly to index
            return redirect()->route('store-visits.index')
                           ->with('success', 'Store visit report created successfully! No action plans needed.');
        }
    }

    public function show($id)
    {
        $visit = StoreVisit::with('actionPlans')->findOrFail($id);
        
        // Check if this visit needs confirmation (has action items but no action plans created)
        $actionItems = $visit->getActionItems();
        $showConfirmation = (session('success') || session('confirm') || request()->has('confirm')) && 
                           count($actionItems) > 0 && 
                           $visit->actionPlans->isEmpty();
        
        return Inertia::render('StoreVisit/Show', [
            'visit' => $visit,
            'actionItemsPreview' => $actionItems,
            'showConfirmation' => $showConfirmation
        ]);
    }

    public function edit($id)
    {
        $visit = StoreVisit::findOrFail($id);
        
        // Check if user can edit this visit
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        if (!$isAdmin && $visit->user_id !== $user->id) {
            abort(403, 'You can only edit your own visits.');
        }
        
        // Get restaurants for dropdown
        $restaurants = Restaurant::where('is_active', true)
                                 ->select('id', 'name', 'code', 'location')
                                 ->orderBy('code')
                                 ->get();
        
        return Inertia::render('StoreVisit/Edit', [
            'visit' => $visit,
            'restaurants' => $restaurants
        ]);
    }

    public function update(Request $request, $id)
    {
        $visit = StoreVisit::findOrFail($id);
        
        // Check if user can update this visit
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        if (!$isAdmin && $visit->user_id !== $user->id) {
            abort(403, 'You can only update your own visits.');
        }
        
        // Validate the request
        $validated = $request->validate([
            'restaurant_name' => 'required|string|max:255',
            'mic' => 'required|in:Morning,Evening',
            'visit_date' => 'required|date',
            'purpose_of_visit' => 'required|array',
            // Add other validation rules as needed
        ]);
        
        // Update the visit
        $visit->update($validated);
        
        // Recalculate and update score
        $visit->score = $visit->calculateScore();
        $visit->save();
        
        return redirect()->route('store-visits.index')->with('success', 'Store visit updated successfully!');
    }

    public function actionPlans()
    {
        $restaurants = Restaurant::orderBy('name')->get();
        $visits = StoreVisit::with('restaurant')->latest()->get();
        
        return Inertia::render('StoreVisit/ActionPlan', [
            'restaurants' => $restaurants,
            'visits' => $visits,
            'visitId' => null, // For when not coming from specific visit
            'actionPlans' => [] // Will be populated with actual action plans later
        ]);
    }

    public function storeActionPlan(Request $request)
    {
        // Store action plan logic here
        return redirect()->route('store-visits.action-plans')->with('success', 'Action plan created successfully!');
    }

    public function bulkUpdate(Request $request)
    {
        $request->validate([
            'visits' => 'required|array',
            'visits.*' => 'exists:store_visits,id',
            'status' => 'required|in:Draft,Submitted,Pending Review,Approved'
        ]);

        StoreVisit::whereIn('id', $request->visits)
                  ->update(['status' => $request->status]);

        return back()->with('success', count($request->visits) . ' visit(s) updated successfully!');
    }

    public function exportPdf(Request $request)
    {
        // Build the same query as index
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        $query = StoreVisit::with('user');
        
        if (!$isAdmin) {
            $query->where('user_id', $user->id);
        }
        
        // Apply same filters as index method
        $this->applyFilters($query, $request);
        
        $visits = $query->latest('visit_date')->get();
        
        // Calculate statistics
        $statistics = [
            'total' => $visits->count(),
            'completed' => $visits->where('status', 'Submitted')->count() + $visits->where('status', 'Approved')->count(),
            'pending' => $visits->whereIn('status', ['Draft', 'Pending Review'])->count(),
            'average_score' => $visits->count() > 0 ? round($visits->avg('score') ?? 0) : 0,
            'with_action_items' => $visits->filter(function($visit) {
                return count($visit->getActionItems()) > 0;
            })->count()
        ];
        
        $pdf = Pdf::loadView('exports.store-visits-pdf', compact('visits', 'statistics', 'user', 'isAdmin'))
                  ->setPaper('a4', 'landscape');
        
        return $pdf->download('store-visits-report-' . now()->format('Y-m-d-H-i-s') . '.pdf');
    }

    public function exportExcel(Request $request)
    {
        // Build the same query as index
        $user = auth()->user();
        $isAdmin = $user->roles && $user->roles->contains('name', 'admin');
        
        $query = StoreVisit::with('user');
        
        if (!$isAdmin) {
            $query->where('user_id', $user->id);
        }
        
        $this->applyFilters($query, $request);
        
        $visits = $query->latest('visit_date')->get();
        
        return Excel::download(
            new StoreVisitsExport($visits), 
            'store-visits-report-' . now()->format('Y-m-d-H-i-s') . '.xlsx'
        );
    }

    public function exportSinglePdf($id)
    {
        $visit = StoreVisit::with('user')->findOrFail($id);
        
        $pdf = Pdf::loadView('exports.single-visit-pdf', compact('visit'))
                  ->setPaper('a4');
        
        return $pdf->download('store-visit-' . $visit->restaurant_name . '-' . $visit->visit_date->format('Y-m-d') . '.pdf');
    }

    private function applyFilters($query, $request)
    {
        if ($request->filled('restaurant')) {
            $query->where('restaurant_name', 'LIKE', '%' . $request->restaurant . '%');
        }
        
        if ($request->filled('mic')) {
            $query->where('mic', $request->mic);
        }
        
        if ($request->filled('date_from')) {
            $query->where('visit_date', '>=', $request->date_from);
        }
        
        if ($request->filled('date_to')) {
            $query->where('visit_date', '<=', $request->date_to);
        }
        
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('restaurant_name', 'LIKE', '%' . $search . '%')
                  ->orWhere('general_comments', 'LIKE', '%' . $search . '%')
                  ->orWhere('what_did_you_see', 'LIKE', '%' . $search . '%');
            });
        }
        
        if ($request->filled('purpose')) {
            $query->whereJsonContains('purpose_of_visit', $request->purpose);
        }
        
        if ($request->filled('score_min')) {
            $query->whereRaw('COALESCE(score, 0) >= ?', [$request->score_min]);
        }
        
        if ($request->filled('score_max')) {
            $query->whereRaw('COALESCE(score, 0) <= ?', [$request->score_max]);
        }
    }

    /**
     * Auto-generate action plans for "No" answers in store visits
     */
    private function generateActionPlans(StoreVisit $storeVisit)
    {
        $actionItems = $storeVisit->getActionItems();
        
        // Batch create for better performance
        $actionPlansData = [];
        
        foreach ($actionItems as $item) {
            $actionPlansData[] = [
                'store_visit_id' => $storeVisit->id,
                'item' => $item['question'],
                'issue' => $item['question'] . ' - Issue identified during visit',
                'action_required' => $this->generateActionDescription($item['field'], $item['question']),
                'priority' => $this->determinePriority($item['field']),
                'status' => 'Pending',
                'assigned_to' => null,
                'due_date' => null,
                'is_approved' => true,
                'notes' => $item['comment'] ?: 'Action required based on store visit findings',
                // Visit context
                'visit_purpose' => is_array($storeVisit->purpose_of_visit) ? 
                    implode(', ', $storeVisit->purpose_of_visit) : $storeVisit->purpose_of_visit,
                'area_manager' => auth()->user() ? auth()->user()->name : 'System',
                'restaurant_manager' => 'To be assigned',
                // 5W1H fields
                'what' => $item['question'] . ' needs improvement',
                'why' => 'Non-compliance identified during quality visit',
                'when_detail' => 'During visit on ' . $storeVisit->visit_date->format('Y-m-d'),
                'where' => $storeVisit->restaurant_name,
                'who' => 'Restaurant staff and management',
                'how' => $this->generateActionDescription($item['field'], $item['question']),
                'created_at' => now(),
                'updated_at' => now()
            ];
        }
        
        // Bulk insert for better performance
        if (!empty($actionPlansData)) {
            ActionPlan::insert($actionPlansData);
        }
    }

    /**
     * Generate detailed action description based on the failed item
     */
    private function generateActionDescription($field, $question)
    {
        $actionDescriptions = [
            'oca_board_followed' => 'Review OCA board procedures with staff and ensure proper communication of all items',
            'staff_know_duty' => 'Conduct side duty training session and create duty assignment checklist',
            'coaching_directing' => 'Implement proper coaching and directing procedures with management training',
            'smile_greetings' => 'Train staff on customer service standards and friendly greeting protocols',
            'suggestive_selling' => 'Conduct suggestive selling training and implement sales targets',
            'offer_promotion' => 'Ensure staff are informed about current promotions and train on promotion offerings',
            'thank_direction' => 'Train staff on proper customer farewell procedures and direction giving',
            'team_work_hustle' => 'Enhance team coordination and work pace through team building exercises',
            'order_accuracy' => 'Review and improve order taking procedures, implement double-check system',
            'service_time' => 'Optimize service time to meet standards through process improvement',
            'dine_in' => 'Improve dine-in service quality and customer experience',
            'take_out' => 'Enhance take-out service procedures and packaging standards',
            'family' => 'Improve family-friendly service approach and facilities',
            'delivery' => 'Optimize delivery service procedures and timing',
            'drive_thru' => 'Enhance drive-thru service speed and accuracy',
            'weekly_schedule' => 'Review scheduling practices and overtime management',
            'mod_financial_goal' => 'Ensure MOD understands and tracks financial goals',
            'sales_objectives' => 'Train cashiers on sales objectives and targets',
            'cash_policies' => 'Review and reinforce cash handling policies',
            'daily_waste' => 'Implement proper waste management procedures and tracking',
            'ttf_followed' => 'Ensure TTF (Time, Temperature, Freshness) standards are met',
            'sandwich_assembly' => 'Review sandwich assembly standards and procedures',
            'qsc_completed' => 'Complete QSC (Quality, Service, Cleanliness) checklist properly',
            'oil_standards' => 'Monitor and maintain oil quality standards',
            'day_labels' => 'Ensure proper day labeling procedures are followed',
            'equipment_working' => 'Inspect and repair all equipment to working condition',
            'fryer_condition' => 'Replace or repair fryer baskets to meet standards',
            'vegetable_prep' => 'Review vegetable preparation and salad prep standards',
            'employee_appearance' => 'Ensure all employees meet grooming and appearance standards',
            'equipment_wrapped' => 'Properly wrap and hang all equipment according to standards',
            'sink_setup' => 'Set up compartment sink properly according to health standards',
            'sanitizer_standard' => 'Ensure sanitizer meets required standards and concentration',
            'dining_area_clean' => 'Maintain clean dining area and family area without clutter',
            'restroom_clean' => 'Ensure restroom/handwash area has tissue and is properly cleaned'
        ];

        return $actionDescriptions[$field] ?? "Address and improve: {$question}";
    }

    /**
     * Determine priority level based on the failed item
     */
    private function determinePriority($field)
    {
        $highPriorityItems = [
            'cash_policies', 'oil_standards', 'sanitizer_standard', 'equipment_working',
            'qsc_completed', 'order_accuracy', 'service_time'
        ];
        
        $mediumPriorityItems = [
            'oca_board_followed', 'coaching_directing', 'team_work_hustle',
            'ttf_followed', 'sandwich_assembly', 'daily_waste'
        ];
        
        if (in_array($field, $highPriorityItems)) {
            return 'High';
        } elseif (in_array($field, $mediumPriorityItems)) {
            return 'Medium';
        } else {
            return 'Low';
        }
    }

    /**
     * Confirm store visit and generate action plans
     */
    public function confirmAndCreateActionPlans(Request $request)
    {
        \Log::info('Action plans confirmation requested', [
            'visit_id' => $request->input('visit_id'),
            'user' => auth()->user() ? auth()->user()->name : 'Not authenticated'
        ]);
        
        try {
            $visitId = $request->input('visit_id');
            if (!$visitId) {
                \Log::error('No visit_id provided in request');
                
                if ($request->expectsJson()) {
                    return response()->json(['error' => 'Visit ID is required'], 400);
                }
                return redirect()->back()->with('error', 'Visit ID is required.');
            }
            
            $storeVisit = StoreVisit::findOrFail($visitId);
            
            // Generate action plans for "No" answers
            $actionItems = $storeVisit->getActionItems();
            $actionItemsCount = count($actionItems);
            
            if ($actionItemsCount > 0) {
                $this->generateActionPlans($storeVisit);
                
                // Update status to approved (confirmed)
                $storeVisit->status = 'Approved';
                $storeVisit->save();
                
                $message = "Store visit confirmed and {$actionItemsCount} action plans created successfully!";
            } else {
                // Update status to approved (confirmed)
                $storeVisit->status = 'Approved';
                $storeVisit->save();
                
                $message = "Store visit confirmed! No action plans needed as all items passed inspection.";
            }

            return redirect()->route('store-visits.index')->with('success', $message);
            
        } catch (\Exception $e) {
            \Log::error('Action plan creation failed: ' . $e->getMessage(), [
                'visit_id' => $request->input('visit_id'),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to create action plans: ' . $e->getMessage());
        }
    }
}
