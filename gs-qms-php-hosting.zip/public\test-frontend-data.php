<?php

require_once '../vendor/autoload.php';

// Bootstrap Laravel
$app = require_once '../bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

header('Content-Type: application/json');

try {
    // Find RM user
    $user = \App\Models\User::where('email', 'rm@ghidas.com')->with('roles')->first();
    
    if (!$user) {
        echo json_encode(['error' => 'User not found']);
        exit;
    }
    
    // Get permissions like HandleInertiaRequests does
    $permissionsData = [];
    
    foreach ($user->roles as $role) {
        $rolePermissions = \App\Models\RolePagePermission::with('pagePermission')
            ->where('role_id', $role->id)
            ->get();
        
        foreach ($rolePermissions as $rolePermission) {
            $pageKey = $rolePermission->pagePermission->page_key;
            
            if (!isset($permissionsData[$pageKey])) {
                $permissionsData[$pageKey] = [
                    'can_view' => false,
                    'can_create' => false,
                    'can_edit' => false,
                    'can_delete' => false,
                    'can_approve' => false,
                ];
            }
            
            $permissionsData[$pageKey]['can_view'] = $permissionsData[$pageKey]['can_view'] || $rolePermission->can_view;
            $permissionsData[$pageKey]['can_create'] = $permissionsData[$pageKey]['can_create'] || $rolePermission->can_create;
            $permissionsData[$pageKey]['can_edit'] = $permissionsData[$pageKey]['can_edit'] || $rolePermission->can_edit;
            $permissionsData[$pageKey]['can_delete'] = $permissionsData[$pageKey]['can_delete'] || $rolePermission->can_delete;
            $permissionsData[$pageKey]['can_approve'] = $permissionsData[$pageKey]['can_approve'] || $rolePermission->can_approve;
        }
    }
    
    echo json_encode([
        'user' => [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'roles' => $user->roles->map(function($role) {
                return [
                    'id' => $role->id,
                    'name' => $role->name
                ];
            })
        ],
        'permissions' => $permissionsData
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}